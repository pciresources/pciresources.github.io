# out_GrepRouter

require 'fluent/output'

module Fluent
#  class GrepRouterOutput < BufferedOutput
  class GrepRouterLabelOutput < Output
    # First, register the plugin. NAME is the name of this plugin
    # and identifies the plugin in the configuration file.
    Fluent::Plugin.register_output('GrepRouterLabel', self)

  REGEXP_MAX_NUM = 20

  # config_param defines a parameter. You can refer a parameter via @path instance variable
    # Without :default, a parameter is required.
    # config_param :path, :string
  config_param :elselabel, :string, :default => nil
  (1..REGEXP_MAX_NUM).each {|i| config_param :"regexp#{i}",  :string, :default => nil }
  (1..REGEXP_MAX_NUM).each {|i| config_param :"label#{i}", :string, :default => nil }

  # for test
#  attr_reader :regexps
#  attr_reader :tags

	
    # This method is called before starting.
    # 'conf' is a Hash that includes configuration parameters.
    # If the configuration is invalid, raise Fluent::ConfigError.
    def configure(conf)
      super

      # You can also refer raw parameter via conf[name].
      # @path = conf['path']
		@regexps = {}
		# @regexps[@input_key] = Regexp.compile(@regexp) if @input_key and @regexp
		(1..REGEXP_MAX_NUM).each do |i|
		  next unless conf["regexp#{i}"]
		  key, regexp = conf["regexp#{i}"].split(/ /, 2)
		  raise Fluent::ConfigError, "regexp#{i} does not contain 2 parameters" unless regexp
		  # raise Fluent::ConfigError, "regexp#{i} contains a duplicated key, #{key}" if @regexps[key]
		  # @regexps[key] = Regexp.compile(regexp)
		  raise Fluent::ConfigError, "no matching label#{i} for regexp#{i}" unless conf["label#{i}"]
		  @regexps[i] = [key, Regexp.compile(regexp), conf["label#{i}"]]
# $log.info "GrepRouter conf regexps:", i, key, regexp, conf["label#{i}"]
		end

    end

    # This method is called when starting.
    # Open sockets or files here.
    def start
      super
    end

    # This method is called when shutting down.
    # Shutdown the thread and close sockets or files here.
    def shutdown
      super
    end


  def emit(tag, es, chain) 
     es.each do |time,record| 
	$log.debug "GrepRouter.emit ", tag, time, record
		
	destLabel = ""
	@regexps.each do |i, arr|
	    key = arr[0]
            regexp = arr[1]
            tag = arr[2]
#	$log.info "GrepRouter.emit ", tag, time, record
#	$log.info "GrepRouter.emit ", key:key, regexp:regexp, tag:tag
#	$log.info "GrepRouter.emit ", record:record
	    compareTo = record[key]
            if (regexp.match(record[key].to_s))
				destLabel = tag
		end
        end #regexps.each

        if (destLabel.nil? || destLabel.empty?)
			if elselabel.nil?
				# no else tag
				else
					destLabel = elselabel
                end
        end

		if (destLabel.nil? || destLabel.empty?)
            # no match
			$log.debug "GrepRouter.emit nomatch", tag
        else
			# change label
			$log.debug "GrepRouter.emit changelabel:", destLabel            
#			$log.info	 "GrepRouter.emit changeLabel:", destLabel            
			label = Engine.root_agent.find_label(destLabel)
			router = label.event_router
			router.emit(tag, time, record) 
        end

  end 
end

  end
end


