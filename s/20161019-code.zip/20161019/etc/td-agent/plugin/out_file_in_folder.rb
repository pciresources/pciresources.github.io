require 'fileutils'
require 'zlib'
require 'time'

require 'fluent/output'
#require 'fluent/config/error'
# TODO remove ...
#require 'fluent/plugin/file_util'

module Fluent
	class FileInFolderOutput < Output
		include Fluent::HandleTagNameMixin

		Fluent::Plugin.register_output('file_in_folder', self)

		FILE_PERMISSION = 0644

		desc "The Folder Path where the files are written."
		config_param :path, :string
		desc "The field name in the object that is used for file name"
		config_param :field_name, :string


		def configure(conf)
			super
			@file_perm = FILE_PERMISSION

#			$log.info "conf field_name #{@field_name} "	# + @field_name
#			$log.info "conf field_name #{field_name} "	# + @field_name

#			$log.info "conf field_name " + field_name
#			$log.info "conf path #{@path} " 		# + @path

		end

		# This method is called when starting.
		# Open sockets or files here.
		def start
			super
		end

		# This method is called when shutting down.
		# Shutdown the thread and close sockets or files here.
		def shutdown
			super
		end

		def format(tag, time, record)
			r = inject_values_to_record(tag, time, record)
			@formatter.format(tag, time, r)
		end

#		def write(chunk)
#			data = chunk.read
#			print data
#			
#		end


		def handle_record(tag, time, record)
			mykey = "#{record[@field_name]}"
			$log.info "handle_record ", field_name:field_name
			$log.info "handle_record ", field_name:@field_name
			$log.info "handle_record ", record:record
			$log.info "handle_record (1)#{@field_name} (2) #{record[@field_name]}"
			filepath = @path + "#{record[@field_name]}"
			$log.info "#{filepath}"
			File.open(filepath, "ab", @file_perm) do |f|
				value = record[@field_name]
				# value.write_to(f)
				f.write(value)
			end
		end

		def emit(tag, es, chain)
			$log.info "emit"
			es.each do |time, record|
				handle_record(tag, time, record)
			end
			chain.next
		end


	end
end
  

