require 'fluent/filter' 

module Fluent
        class NetflowNormalizerFilter < Filter
        Fluent::Plugin.register_filter('NetflowNormalizer', self)

                def configure(conf)
                        super
                end
                def start
                        super
                end
                def shutdown
                        super
                end
                def filter(tag, time, record)					
					record["pci.version"] = record["version"];

					 # Parse IP
					 if !record["ipv4_src_addr"].nil?
						record["pci.src_ip"] = record["ipv4_src_addr"]
						record["pci.dst_ip"] = record["ipv4_dst_addr"]
						record["pci.ip_version"] = 4;
					 elsif !record["ipv6_src_addr"].nil?
						record["pci.src_ip"] = record["ipv6_src_addr"]
						record["pci.dst_ip"] = record["ipv6_dst_addr"]
						record["pci.ip_version"] = 6;
					 elsif !record["sourceIPv4Address"].nil?
						record["pci.src_ip"] = record["sourceIPv4Address"]
						record["pci.dst_ip"] = record["destinationIPv4Address"]
						record["pci.ip_version"] = 4;
					 elsif !record["sourceIPv6Address"].nil?
						record["pci.src_ip"] = record["sourceIPv6Address"]
						record["pci.dst_ip"] = record["destinationIPv6Address"]
						record["pci.ip_version"] = 6;
					 else
						$log.error "Unknown IP addresses ", record:record
					 end

				if record["protocolIdentifier"].nil?
					record["pci.protocol"] = record["protocol"].to_s
				else
					record["pci.protocol"] = record["protocolIdentifier"].to_s
				end
					 

					 # Parse ports
#				if (record["pci.protocol_name"] =~ /(TCP|UDP)/)
				if (record["pci.protocol"] =~ /(6|17)/)
					 if !record["l4_src_port"].nil?
						record["pci.src_port"] = record["l4_src_port"].to_s
						record["pci.dst_port"] = record["l4_dst_port"].to_s
					 elsif !record["sourceTransportPort"].nil?
						record["pci.src_port"] = record["sourceTransportPort"].to_s
						record["pci.dst_port"] = record["destinationTransportPort"].to_s
					 elsif !record["ipv4_src_port"].nil?
						record["pci.src_port"] = record["ipv4_src_port"].to_s
						record["pci.dst_port"] = record["ipv4_dst_port"].to_s
					 else
						$log.error "Unknown IP ports  ", record:record
					 end					 
				else
						record["pci.src_port"] = "0"
						record["pci.dst_port"] = "0"
				end
                    # reemit record
					record
                end
    end 
end


