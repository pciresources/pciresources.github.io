

require 'fluent/filter'
require 'csv'
require 'ipaddr'

module Fluent
        class MatchACLFilter < Filter
                include Fluent::HandleTagNameMixin

                Fluent::Plugin.register_filter('MatchACL', self)

                config_param :ip1, :string, :default => nil
                config_param :ip2, :string, :default => nil
                config_param :port1, :string, :default => nil
                config_param :port2, :string, :default => nil
                config_param :proto, :string, :default => nil
                config_param :table_file, :string, :default => nil
                config_param :aclmatch, :string, :default => nil

                def create_lookup_table(file)
                        lookup_table = {}
                        rowno = 0
                        CSV.foreach(file) do |row|
                                rowno = rowno + 1
                                key = "#{row[0]},#{row[1]},#{row[2].upcase}"
#$log.warn "len=", row.length
                                if (row.length >= 4)
                                        if (row[3] != "0")
                                                key = key + "," + row[3]
                                        end
                                end
$log.debug "csv-key=#{key}:#{row[4]}"
                                lookup_table[key] = row[4]
                        end
#                 end
                  return lookup_table
                end

                def configure(conf)
                        super
                        @lookup_table = create_lookup_table(table_file)
                        super
                        @lookup_table = create_lookup_table(table_file)
                end

                def start
                        super
                end

                def shutdown
                        super
                end

                def filter(tag, time, record)
					# Look for value based on IP addresses
					value = lookup_value(record[@ip1], record[@ip2], record[@proto], record[@port1], record[@port2])
					iSrcBits = 32
					#We may need to look for values based on network ranges (/24 to /16)
					while value == "nomatch" and iSrcBits > 16
						#src
						if iSrcBits == 32 
							iSrcBits = 25
						end
						iSrcBits = iSrcBits - 1;
						ipsrc = iptosubnet(record[@ip1], iSrcBits)
						value = lookup_value(ipsrc, record[@ip2], record[@proto], record[@port1], record[@port2])
					end
						#dst
					iDstBits = 32
					while value == "nomatch" and iDstBits > 16
						if iDstBits == 32 
							iDstBits = 25
						end
						iDstBits = iDstBits - 1;
						ipdst = iptosubnet(record[@ip2], iDstBits)
						value = lookup_value(record[@ip1], ipdst, record[@proto], record[@port1], record[@port2])
					end

					#src & dst???  TODO
					iSrcBits = 32
					#We may need to look for values based on network ranges (/24 to /16)
					while value == "nomatch" and iSrcBits > 16
						#src
						if iSrcBits == 32 
							iSrcBits = 25
						end
						iSrcBits = iSrcBits - 1;
						ipsrc = iptosubnet(record[@ip1], iSrcBits)
						iDstBits = 32
						while value == "nomatch" and iDstBits > 16
							if iDstBits == 32 
								iDstBits = 25
							end
							iDstBits = iDstBits - 1;
							ipdst = iptosubnet(record[@ip2], iDstBits)
							value = lookup_value(ipsrc, ipdst, record[@proto], record[@port1], record[@port2])
						end

					end


                    record[@aclmatch] = value
                    record
                end

				def iptosubnet(ip, bits)					
$log.debug "ipaddr=", "#{ip}/#{bits}"
					subnet = ip
#					begin
						ipchg = IPAddr.new("#{ip}")
#						subnet = 
						subnet = ipchg.mask("#{bits}").to_s
						subnet = "#{subnet}/#{bits}"
#						subnet = ipchg.to_s
#					rescue => error
#$log.error "error: #{error.message}"
#					end
#$log.warn "subnet=", subnet
					return subnet
				end
				
                def lookup_value(ip1, ip2, proto, port1, port2)
					value = "nomatch"
                    searchkey = ip1 + "," + ip2 + "," + proto
$log.debug "search=#{searchkey}"					
                    if (@lookup_table.has_key?(searchkey))
						value =  @lookup_table[searchkey]
                    else
						# compare with 4 parameters
                        searchkey = searchkey + "," + port2
$log.debug "search=#{searchkey}"					
						if (@lookup_table.has_key?(searchkey))
							value =  @lookup_table[searchkey]
                        else
							# ip2 -> ip1
                            # compare with 3 parameters
                            searchkey = ip2 + "," + ip1 + "," + proto
$log.debug "search=#{searchkey}"					
							if (@lookup_table.has_key?(searchkey))
								value =  @lookup_table[searchkey]
							else
								# compare with 4 parameters
                                searchkey = searchkey + "," + port1
$log.debug "search=#{searchkey}"					
                                if (@lookup_table.has_key?(searchkey))
									value =  @lookup_table[searchkey]
								end
                            end
						end
                    end
if value != "nomatch"
$log.debug "ACL match found search=#{searchkey}"					
end
					return value
                end
				
				
    end
end
