
require 'fluent/filter' 
require 'mysql2'

module Fluent
        class PCIFlowFilter < Filter
        Fluent::Plugin.register_filter('PCIFlow', self)

			config_param :db_host, :string, :default => "127.0.0.1"
			config_param :db_port, :integer, :default => 3306
			config_param :db_name, :string
			config_param :db_username, :string
			config_param :db_password, :string, :default => '', :secret => true

                def configure(conf)
                        super
                end
                def start
                        super
                end
                def shutdown
                        super
                end
                def filter(tag, time, record)			
if  record["pci.ip_version"] == 6
	return
end
			begin
					 	con = Mysql2::Client.new(:host => @db_host, 
									:username =>@db_username, 
									:password =>@db_password, 
									:database =>@db_name,
									:flags => Mysql2::Client::MULTI_STATEMENTS)

					record["flow.protocol_name"] = record["pci.protocol_name"]
#$log.info "PCIFlow:filter()", record:record					
                     if (record["pci.protocol_name"] =~ /(TCP|UDP)/)
						sql = "SELECT * FROM service WHERE ipv4 = '" + record["pci.dst_ip"] +"'"\
							+ " AND proto = '" + record["pci.protocol_name"] +"'"\
							+ " AND port = '" + record["pci.dst_port"] +"'"

#$log.info "PCIFlow:filter() 1 ", sql:sql					
						rs = con.query(sql)
						if rs.count > 0
#$log.info "PCIFlow:filter() 1a "
							record["flow.type"] = "tcpudp"			
							record["flow.ipsrc"] = record["pci.src_ip"]
							record["flow.ipdst"] = record["pci.dst_ip"]
							record["flow.dstport"] = record["pci.dst_port"]
						else
#$log.info "PCIFlow:filter() 1b "
							sql = "SELECT * FROM service WHERE ipv4 = '" + record["pci.src_ip"] +"'"\
								+ " AND proto = '" + record["pci.protocol_name"] +"'"\
								+ " AND port = '" + record["pci.src_port"] +"'"
#$log.info "PCIFlow:filter() 2 ", sql:sql					
							rs = con.query(sql)
							if rs.count > 0
#$log.info "PCIFlow:filter() 2a "
								record["flow.type"] = "tcpudp"			
								record["flow.ipsrc"] = record["pci.dst_ip"]
								record["flow.ipdst"] = record["pci.src_ip"]
								record["flow.dstport"] = record["pci.src_port"]
							else
#$log.info "PCIFlow:filter() 3 "				
								record["flow.type"] = "unknown"			
								record["flow.ipsrc"] = record["pci.src_ip"]
								record["flow.ipdst"] = record["pci.dst_ip"]
								record["flow.srcport"] = record["pci.src_port"]
								record["flow.dstport"] = record["pci.dst_port"]
							end 
						end
					 else
#$log.info "PCIFlow:filter() 4 "
						record["flow.type"] = "other"
						record["flow.ipsrc"] = record["pci.src_ip"]
						record["flow.ipdst"] = record["pci.dst_ip"]
						record["flow.srcport"] = 0
						record["flow.dstport"] = 0
					 end

#$log.info "PCIFlow:filter()", type:record["flow.type"]					

					case record["flow.type"]
					when "tcpudp"
						sqlu = "INSERT INTO flow (ipsrc, ipdst, proto, dstport, hits) VALUES ('" + record["flow.ipsrc"] +"'"\
						", '" + record["flow.ipdst"] +"'"\
						", '" + record["flow.protocol_name"] +"'"\
						", '" + record["flow.dstport"] +"'"\
						", 1) ON duplicate KEY UPDATE hits = hits + 1, dateLastSeen = NOW()";
						sqlud = "INSERT INTO dailyflow (ipsrc, ipdst, proto, dstport, hits, dailyDate) VALUES ('" + record["flow.ipsrc"] +"'"\
						", '" + record["flow.ipdst"] +"'"\
						", '" + record["flow.protocol_name"] +"'"\
						", '" + record["flow.dstport"] +"'"\
						", 1, CURDATE()) ON duplicate KEY UPDATE hits = hits + 1";
					when "unknown"
						sqlu = "INSERT INTO unknownFlow (ipsrc, ipdst, proto, srcport, dstport, hits) VALUES ('" + record["flow.ipsrc"] +"'"\
						", '" + record["flow.ipdst"] +"'"\
						", '" + record["flow.protocol_name"] +"'"\
						", '" + record["flow.srcport"] +"'"\
						", '" + record["flow.dstport"] +"'"\
						", 1) ON duplicate KEY UPDATE hits = hits + 1, dateLastSeen = NOW()";
						sqlud = "INSERT INTO unknownDailyFlow (ipsrc, ipdst, proto, srcport, dstport, hits, dailyDate) VALUES ('" + record["flow.ipsrc"] +"'"\
						", '" + record["flow.ipdst"] +"'"\
						", '" + record["flow.protocol_name"] +"'"\
						", '" + record["flow.srcport"] +"'"\
						", '" + record["flow.dstport"] +"'"\
						", 1, CURDATE()) ON duplicate KEY UPDATE hits = hits + 1";
					when "other"
						sqlu = "INSERT INTO otherFlow (ipsrc, ipdst, proto, hits) VALUES ('" + record["flow.ipsrc"] +"'"\
						", '" + record["flow.ipdst"] +"'"\
						", '" + record["flow.protocol_name"] +"'"\
						", 1) ON duplicate KEY UPDATE hits = hits + 1, dateLastSeen = NOW()";
						sqlud = "INSERT INTO otherDailyFlow (ipsrc, ipdst, proto, hits, dailyDate) VALUES ('" + record["flow.ipsrc"] +"'"\
						", '" + record["flow.ipdst"] +"'"\
						", '" + record["flow.protocol_name"] +"'"\
						", 1, CURDATE()) ON duplicate KEY UPDATE hits = hits + 1";
					end
# $log.info "insert/update #{sqlu}"	
# $log.info "insert/update #{sqlud}"	
					rs = con.query(sqlu)
					rs = con.query(sqlud)
#			rescue Error => terr
# $log.error "PCIFlow:Filter() Exception ", terr:terr
			rescue => err
 $log.error "PCIFlow:Filter() Exception ", err:err
 $log.error "PCIFlow:Filter() Exception Trace ", err.backtrace
#			else
# $log.error "PCIFlow:Filter() Exception other "
			end

                    # reemit record
					record
                end
    end 
end

