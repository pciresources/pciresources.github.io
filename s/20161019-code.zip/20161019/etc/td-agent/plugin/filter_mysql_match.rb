
require 'fluent/filter'
# coding: utf-8
# require "csv"
# require 'mysql'

module Fluent
	class MysqlMatchExistFilter < Filter
		include Fluent::HandleTagNameMixin
		
		Fluent::Plugin.register_filter('MysqlMatchExist', self)

		config_param :db_host, :string, :default => "127.0.0.1"
		config_param :db_port, :integer, :default => 3306
		config_param :db_name, :string
		config_param :db_username, :string
		config_param :db_password, :string, :default => '', :secret => true

		config_param :db_table, :string, :default => nil
		config_param :db_field_key, :string, :default => nil
		config_param :db_field_dateAdded, :string, :default => nil
		config_param :db_field_lastSeen, :string, :default => nil

		config_param :input_field, :string, :default => nil
		config_param :output_field, :string, :default => nil
		config_param :output_tag, :string

	def configure(conf)
		super
	#	$log.info "match:configure()"
		if @db_table.nil?
        		raise Fluent::ConfigError, "db_table MUST be specified, but missing"
      		end
      		# TODO : more validations

		@sql = "SELECT #{db_field_key}, #{db_field_dateAdded}, #{db_field_lastSeen}  FROM #{db_table} WHERE #{db_field_key} = "		
	#	$log.info "sql ->[#{@sql}]"
	end


	def start
		super
	end

	def shutdown
		super
	end

	def format(tag, time, record)
		[tag, time, @format_proc.call(tag, time, record)].to_msgpack
	end

	def filter(tag, time, record)
	#	$log.info "match:filter()"
#		con = Mysql.new(@db_host, @db_username, @db_password, @db_name)
		con = Mysql2::Client.new(:host => @db_host, 
				:username =>@db_username, 
				:password =>@db_password, 
				:database =>@db_name,
				:flags => Mysql2::Client::MULTI_STATEMENTS)


	#	$log.info "match:filter() mysql conn"
		mykey = "#{record[@input_field]}"
#		$log.info "match:filter() sql: [" + @sql + "'" + mykey + "'" + "]"
		rs = con.query(@sql + "'" + mykey + "'")
#		n_rows = rs.num_rows
		n_rows = rs.count
	#	$log.info "match:filter() query #{n_rows} rows"
		if n_rows > 0 
			# existing item
			sqli = "SELECT NOW()"
#      			rs.each_hash do |row|
			results.each do |row|
				record[@db_field_dateAdded] = row[@db_field_dateAdded]
				record[@db_field_lastSeen] = row[@db_field_lastSeen]
				record[@output_field] = "existing"
				sqli = "UPDATE #{db_table} SET #{db_field_lastSeen} = NOW() WHERE #{db_field_key} = '#{mykey}'"
    			end   
      	
      		else
      			# new item
			record[@db_field_dateAdded] = Fluent::Engine.now
			record[@db_field_lastSeen] = Fluent::Engine.now
			record[@output_field] = "new"
			sqli = "INSERT INTO #{db_table} (#{db_field_key}, #{db_field_dateAdded}, #{db_field_lastSeen}) VALUES ('#{mykey}', NOW(), NOW())"			
		end 
      
#		$log.info "match:filter() mysql upd/ins #{sqli}"
		rs = con.query(sqli)
		record
	end

					
				
    end
end


