#!/bin/bash
PIDFILE="$HOME/tmp/nmapq.pid"
FILES=/logmon/queues/nmap/*
let dt=`date +"%Y%m%d"`
MY_PATH="`dirname \"$0\"`"
mkdir -p ${MY_PATH}/${dt}
for f in $FILES
do
  echo "Processing $f file..."
  # take action on each file. $f store current file name
  ip=`cat $f`
	echo scanning with nmap of $ip tcp and udp

echo        nmap -n -T4 -sT -oA ${MY_PATH}/${dt}/tcp-${ip} ${ip} 
        nmap -n -T4 -sT -oA ${MY_PATH}/${dt}/tcp-${ip} ${ip} 
if [ -s ${MY_PATH}/${dt}/tcp-${ip}.xml ]
	then
# 1> /dev/null 2>> /tmp/portscan.log
echo	
/opt/td-agent/embedded/bin/xsltproc ${MY_PATH}/port.xsl  ${MY_PATH}/${dt}/tcp-${ip}.xml	>> /logmon/incoming/tcpudp
fi

echo        nmap -n -T4 -sU -p -1024,3076,5060,5062 -oA ${MY_PATH}/${dt}/udp-${ip} ${ip}
       nmap -n -T4 -sU --max-retries 1 --max-rtt-timeout 100ms -p -1024,3076,5060,5062 -oA ${MY_PATH}/${dt}/udp-${ip} ${ip}

if [ -s ${MY_PATH}/${dt}/udp-${ip}.xml ]
	then
# 1> /dev/null 2>> /tmp/portscan.log
	/opt/td-agent/embedded/bin/xsltproc ${MY_PATH}/port.xsl  ${MY_PATH}/${dt}/udp-${ip}.xml	 >> /logmon/incoming/tcpudp
fi
rm -f $f
done


rm ${PIDFILE}
