#!/bin/bash

# mkdir -p "$HOME/tmp"
# PIDFILE="$HOME/tmp/nmapq.pid"
PIDFILE="/tmp/nmapq.pid"

if [ -e "${PIDFILE}" ] && (ps -u $(whoami) -opid= |
                           grep -P "^\s*$(cat ${PIDFILE})$" &> /dev/null); then
  echo "Already running."
  exit 99
fi

# /root
#/logmon/cron/nmap/nmapq.sh > $HOME/tmp/nmapq.log &
/logmon/cron/nmap/nmapq.sh > /tmp/nmapq.log &

echo $! > "${PIDFILE}"
chmod 644 "${PIDFILE}"

