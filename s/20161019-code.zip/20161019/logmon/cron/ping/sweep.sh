#!/bin/sh
let nb=1
let dt=`date +"%Y%m%d"`
echo ${dt}
echo Start `date` >> /tmp/sweep.log
MY_PATH="`dirname \"$0\"`"
echo ${MY_PATH} >>  /tmp/sweep.log
mkdir -p ${MY_PATH}/${dt}
#cat source.csv | while read line
while IFS=, read iprange rangename
do
#       set iprange=`echo $line | cut -d',' -f1`
#       set rangename=`echo $line | cut -d',' -f2`
        echo $nb ${iprange} ${rangename}
        nmap -n -T4 -sn -oA ${MY_PATH}/${dt}/${rangename} ${iprange} 1> /dev/null 2>> /tmp/sweep.log
	cat  ${MY_PATH}/${dt}/${rangename}.gnmap >> /logmon/incoming/pings
        let nb++
done <  ${MY_PATH}/sources.csv
echo End `date` >> /tmp/sweep.log

