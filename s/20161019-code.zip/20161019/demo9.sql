CREATE DATABASE demo9;
USE demo9;

CREATE TABLE `ipv4` (
  `ipv4` varchar(20) NOT NULL DEFAULT '',
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateLastSeen` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ipv4`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `service` (
  `servicekey` varchar(50) NOT NULL DEFAULT '',
  `ipv4` varchar(20) NOT NULL DEFAULT '',
  `proto` char(3) NOT NULL DEFAULT '',
  `port` int(11) NOT NULL DEFAULT '0',
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateLastSeen` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`servicekey`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `dailyflow` (
  `ipsrc` varchar(20) NOT NULL DEFAULT '',
  `ipdst` varchar(20) NOT NULL DEFAULT '',
  `proto` char(3) NOT NULL DEFAULT '',
  `dstport` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `dailyDate` date NOT NULL,
  PRIMARY KEY (`ipsrc`,`ipdst`,`proto`,`dstport`,`dailyDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `flow` (
  `ipsrc` varchar(20) NOT NULL DEFAULT '',
  `ipdst` varchar(20) NOT NULL DEFAULT '',
  `proto` char(3) NOT NULL DEFAULT '',
  `dstport` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateLastSeen` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ipsrc`,`ipdst`,`proto`,`dstport`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `otherFlow` (
  `ipsrc` varchar(20) NOT NULL DEFAULT '',
  `ipdst` varchar(20) NOT NULL DEFAULT '',
  `proto` char(10) NOT NULL DEFAULT '',
  `hits` int(11) NOT NULL DEFAULT '0',
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateLastSeen` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ipsrc`,`ipdst`,`proto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `otherDailyFlow` (
  `ipsrc` varchar(20) NOT NULL DEFAULT '',
  `ipdst` varchar(20) NOT NULL DEFAULT '',
  `proto` char(10) NOT NULL DEFAULT '',
  `hits` int(11) NOT NULL DEFAULT '0',
  `dailyDate` date NOT NULL,
  PRIMARY KEY (`ipsrc`,`ipdst`,`proto`,`dailyDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `unknownFlow` (
  `ipsrc` varchar(20) NOT NULL DEFAULT '',
  `ipdst` varchar(20) NOT NULL DEFAULT '',
  `proto` char(3) NOT NULL DEFAULT '',
  `srcport` int(11) NOT NULL DEFAULT '0',
  `dstport` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `dateAdded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateLastSeen` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ipsrc`,`ipdst`,`proto`,`srcport`,`dstport`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `unknownDailyFlow` (
  `ipsrc` varchar(20) NOT NULL DEFAULT '',
  `ipdst` varchar(20) NOT NULL DEFAULT '',
  `proto` char(3) NOT NULL DEFAULT '',
  `srcport` int(11) NOT NULL DEFAULT '0',
  `dstport` int(11) NOT NULL DEFAULT '0',
  `dailyDate` date NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipsrc`,`ipdst`,`proto`,`srcport`,`dstport`,`dailyDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE USER 'demo9'@'%' IDENTIFIED by 'password4Demo9';
GRANT ALL ON demo9.* TO 'demo9'@'%';
GRANT CREATE ON demo9 TO 'demo9'@'%';
FLUSH PRIVILEGES;
