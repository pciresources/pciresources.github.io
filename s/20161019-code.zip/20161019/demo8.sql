CREATE DATABASE demo8;
USE demo8;

CREATE TABLE `nf` (
 `nid` int NOT NULL AUTO_INCREMENT,
 `added` timestamp DEFAULT CURRENT_TIMESTAMP,
 `reportinghost` varchar(20)  NULL,
 `srcip` varchar(20)  NULL,
 `dstip` varchar(20)  NULL,
 `srcport` varchar(20)  NULL,
 `dstport` varchar(20)  NULL,
 `protocol` varchar(20)  NULL,
 `nfver` varchar(20)  NULL,
 `dstzone` varchar(20)  NULL,
 `acldirection` varchar(20)  NULL,
 `aclno` varchar(20)  NULL,
 `aclentryid` varchar(20)  NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE USER 'demo8'@'%' IDENTIFIED by 'password4Demo8';
GRANT ALL ON demo8.* TO 'td'@'%';
GRANT CREATE ON demo8 TO 'td'@'%';
FLUSH PRIVILEGES;
